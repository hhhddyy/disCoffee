--------
Download
--------

Software
~~~~~~~~

Source and binary releases: https://pypi.python.org/pypi/networkx-metis/

Github (latest development): https://github.com/networkx/networkx-metis/

